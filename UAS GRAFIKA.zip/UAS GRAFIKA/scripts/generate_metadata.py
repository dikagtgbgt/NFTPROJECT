import os
import json

# Script ini diasumsikan dijalankan dari root project:
# cd "UAS GRAFIKA" lalu python3 scripts/generate_metadata.py

OUTPUT_DIR = "./output"      # berisi nft_1.png, dst
METADATA_DIR = "./metadata"  # target file JSON


# List kata sifat & nama karakter untuk membuat nama yang menarik
ADJECTIVES = [
    "Galactic", "Cyber", "Mystic", "Neon", "Crystal",
    "Shadow", "Solar", "Lunar", "Pixel", "Hologram",
]

CREATURES = [
    "Explorer", "Guardian", "Samurai", "Ranger", "Wizard",
    "Pilot", "Hacker", "Warrior", "Sprite", "Phantom",
]

WORLD_NAME = "Cosmic Crew"  # nama koleksi


def build_nft_name(token_id: int) -> str:
    """
    Bangun nama unik dan menarik berbasis token_id,
    tetapi tetap deterministik (tidak berubah-ubah).
    """
    adj = ADJECTIVES[(token_id - 1) % len(ADJECTIVES)]
    creature = CREATURES[(token_id - 1) % len(CREATURES)]
    return f"{WORLD_NAME} #{token_id} – {adj} {creature}"


def generate_metadata_for_image(filename: str) -> None:
    """
    Membuat 1 file metadata JSON sederhana untuk 1 gambar NFT.
    Struktur yang umum dipakai di marketplace NFT.
    """
    # Contoh: filename = "nft_123.png" -> token_id = 123
    name, ext = os.path.splitext(filename)
    if not name.startswith("nft_"):
        return

    token_id_str = name.replace("nft_", "")
    try:
        token_id = int(token_id_str)
    except ValueError:
        return

    os.makedirs(METADATA_DIR, exist_ok=True)

    metadata = {
        "name": build_nft_name(token_id),
        "description": "Koleksi NFT generatif 'Cosmic Crew' untuk tugas grafika komputer.",
        # Di dunia nyata biasanya ini URL (IPFS/HTTP). Di sini kita pakai path relatif.
        "image": f"output/{filename}",
        "edition": token_id,
        "attributes": [
            # Bisa diisi lebih detail kalau nanti kita simpan info layer yang dipakai.
        ],
    }

    output_path = os.path.join(METADATA_DIR, f"{name}.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    print(f"Metadata untuk {filename} dibuat: {output_path}")


def main() -> None:
    if not os.path.isdir(OUTPUT_DIR):
        raise FileNotFoundError(f"Folder output tidak ditemukan: {OUTPUT_DIR}")

    files = sorted(f for f in os.listdir(OUTPUT_DIR) if f.lower().endswith(".png"))
    if not files:
        raise FileNotFoundError(f"Tidak ada file PNG di folder: {OUTPUT_DIR}")

    for filename in files:
        generate_metadata_for_image(filename)


if __name__ == "__main__":
    main()


