import os
from typing import List

from PIL import Image

# Script ini diasumsikan dijalankan dari root project:
# cd "UAS GRAFIKA" lalu python3 scripts/generate_gifs.py

OUTPUT_DIR = "./output"
GIFS_DIR = "./gifs"
GIF_PREVIEW_DIR = "./gif_all_preview"


def load_images(limit: int | None = None, resize_to: tuple[int, int] | None = None) -> List[Image.Image]:
    files = sorted(f for f in os.listdir(OUTPUT_DIR) if f.lower().endswith(".png"))
    if limit is not None:
        files = files[:limit]

    images: List[Image.Image] = []
    for filename in files:
        path = os.path.join(OUTPUT_DIR, filename)
        img = Image.open(path).convert("RGBA")
        if resize_to is not None:
            img = img.resize(resize_to, Image.LANCZOS)
        images.append(img)
    return images


def save_gif(images: List[Image.Image], target_path: str, duration_ms: int = 100, loop: int = 0) -> None:
    if not images:
        raise ValueError("Tidak ada gambar untuk dibuat GIF.")

    os.makedirs(os.path.dirname(target_path), exist_ok=True)

    first, *rest = images
    first.save(
        target_path,
        save_all=True,
        append_images=rest,
        duration=duration_ms,
        loop=loop,
        optimize=True,
    )
    print(f"GIF berhasil dibuat: {target_path}")


def main() -> None:
    if not os.path.isdir(OUTPUT_DIR):
        raise FileNotFoundError(f"Folder output tidak ditemukan: {OUTPUT_DIR}")

    # GIF besar berisi semua NFT (bisa cukup berat kalau 1000 frame)
    all_images = load_images()
    save_gif(all_images, os.path.join(GIFS_DIR, "all_nft.gif"), duration_ms=80)

    # GIF preview kecil berisi 50 NFT pertama dengan ukuran diperkecil
    preview_images = load_images(limit=50, resize_to=(256, 256))
    save_gif(preview_images, os.path.join(GIF_PREVIEW_DIR, "preview.gif"), duration_ms=120)


if __name__ == "__main__":
    main()


