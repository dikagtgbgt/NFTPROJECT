import os
import random
from PIL import Image

# 1. Tentukan lokasi folder aset dan folder output
# Script ini diasumsikan dijalankan dari root project:
# cd "UAS GRAFIKA" lalu python3 scripts/generate_nft.py
ASSETS_DIR = "./assets"      # folder berisi Background, Body, Face, Head
OUTPUT_DIR = "./output"      # folder hasil gambar


def get_random_layer(folder_name: str) -> Image.Image:
    """
    Mengambil 1 file PNG acak dari subfolder di dalam ASSETS_DIR,
    lalu mengembalikan objek Image yang sudah dikonversi ke RGBA.
    """
    path = os.path.join(ASSETS_DIR, folder_name)
    if not os.path.isdir(path):
        raise FileNotFoundError(f"Folder tidak ditemukan: {path}")

    files = [f for f in os.listdir(path) if f.lower().endswith(".png")]
    if not files:
        raise FileNotFoundException(f"Tidak ada file .png di folder: {path}")

    file_name = random.choice(files)
    full_path = os.path.join(path, file_name)
    return Image.open(full_path).convert("RGBA")


def generate_nft(nomor_urut: int) -> None:
    """
    Fungsi utama untuk generate 1 gambar NFT.
    Layer: Background -> Body -> Face -> Head
    """
    # Ambil layer secara acak
    background = get_random_layer("Background")
    body = get_random_layer("Body")
    face = get_random_layer("Face")
    head = get_random_layer("Head")

    # Samakan ukuran semua layer dengan background (jika perlu)
    body = body.resize(background.size, Image.LANCZOS)
    face = face.resize(background.size, Image.LANCZOS)
    head = head.resize(background.size, Image.LANCZOS)

    # Gabungkan (tumpuk) layer:
    # Background -> Body -> Head -> Face
    # Face ditaruh paling atas supaya wajah tidak ketutupan kepala.
    composite = Image.alpha_composite(background, body)
    composite = Image.alpha_composite(composite, head)
    final_image = Image.alpha_composite(composite, face)

    # Pastikan folder output ada
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Simpan hasil
    output_path = os.path.join(OUTPUT_DIR, f"nft_{nomor_urut}.png")
    final_image.save(output_path)
    print(f"NFT #{nomor_urut} berhasil dibuat: {output_path}")


if __name__ == "__main__":
    # 2. Atur jumlah NFT yang ingin di-generate (misal 1000)
    jumlah_nft = 1000

    for i in range(1, jumlah_nft + 1):
        generate_nft(i)


